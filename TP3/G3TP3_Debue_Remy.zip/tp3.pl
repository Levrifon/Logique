grille([[_,_,_,_,_,_,_,_,_], 
	[_,_,_,_,_,3,_,8,5],
	[_,_,1,_,2,_,_,_,_],
	[_,_,_,5,_,7,_,_,_],
	[_,_,4,_,_,_,1,_,_],
	[_,9,_,_,_,_,_,_,_],
	[5,_,_,_,_,_,_,7,3],
	[_,_,2,_,1,_,_,_,_],
	[_,_,_,_,4,_,_,_,9]]).
	
/*Question 1 */
printline([]) 		:- writeln('|'),!.
printline([T|Q]) 	:- printline2(T) , printline(Q),!.
printline2(A) 		:- integer(A),!,write('|'),write(A).
/* on arrive dans cette derniere branche si A n'est pas un nombre */
printline2(_)		:- write('| ').

/*Question 2 */
myprint([]).
myprint([T|Q]) :- printline(T),myprint(Q).
/*Question 3 */
bonnelongueur([],N)	:- N =:= 0.
bonnelongueur([_|Q],N)	:- bonnelongueur(Q,(N-1)).
/*Question 4 */
bonnetaille([],0).
bonnetaille([T|Q],N)	:- bonnelongueur(T,N), bonnetaille(Q,N),!. 	
bonnetaille([T],N)	:- bonnelongueur(T,N).
/*Question 5 */
:- use_module(library(clpfd)).
verifie([]).
verifie([T|Q]) :- all_different(T), T ins 1..9, verifie(Q).

eclate([A],L2,[A|L2]).
eclate([],L2,L2).
eclate([T|Q],[T1|L1],L) :- L2 = [T|T1] ,eclate(Q,L1,Z), L = [L2|Z].
/* a terminer */
    	   		
