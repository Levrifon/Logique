package logicline.modeleSemantique;

public class TrueClauseException extends Exception 
{
    public TrueClauseException() 
    {
    }
}